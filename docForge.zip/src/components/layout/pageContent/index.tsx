import { style } from "./style";

type props = {
    ContentList?: React.ReactNode;
}

export function PageContent({ContentList}:props) {
    return (
        <div className={style.pageContent}>
            {ContentList&& ContentList}
        </div>
    );
}