import { PageContent } from "@/components/layout/pageContent";
import { MainTemplate } from "@/templates/mainTemplate";

export function Home() {
    return (
        <MainTemplate
            Content={<PageContent
                
            />}
        />
    );
}