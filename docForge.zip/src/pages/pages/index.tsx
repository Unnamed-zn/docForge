import { MainTemplate } from "@/templates/mainTemplate";
import { PageContent } from "@/components/layout/pageContent";
import { ContentList } from "@/components/layout/contentList";

export function Pages() {
    return (
        <MainTemplate
            Content={<PageContent
                ContentList={<ContentList/>}
            />}
        />
    );
}